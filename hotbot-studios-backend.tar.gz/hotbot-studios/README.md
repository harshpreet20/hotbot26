# HotBot Studios — AI Automation & Growth Infrastructure

Production-grade website with real-time AI chatbot, human escalation, WhatsApp integration, and admin dashboard.

## Architecture

```
Frontend (Next.js)  →  Nginx  →  Backend (Express + Socket.io)
                                       ↓
                                   MongoDB
                                       ↓
                              OpenAI API + WhatsApp Webhook
```

## Quick Start

### Prerequisites
- Node.js 18+
- MongoDB (local or Atlas)
- OpenAI API key

### Backend Setup

```bash
cd backend
cp .env.example .env
# Edit .env with your actual credentials
npm install
npm run dev
```

### Frontend Setup

```bash
cd frontend
npm install
npm run dev
```

### Environment Variables

Create `backend/.env`:
```
PORT=4000
NODE_ENV=production
FRONTEND_URL=https://hotbotstudios.com
MONGO_URI=mongodb://localhost:27017/hotbot
OPENAI_API_KEY=sk-your-key-here
OPENAI_MODEL=gpt-4o-mini
WHATSAPP_WEBHOOK=https://your-webhook-url
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/chat` | Send message, get AI response |
| GET | `/api/chat/:session_id` | Get conversation history |
| GET | `/api/chat` | List all conversations (dashboard) |
| POST | `/api/escalate` | Escalate to human agent |
| POST | `/api/agent/message` | Send agent message |
| POST | `/api/agent/takeover` | Agent takes over conversation |
| PATCH | `/api/agent/status` | Update conversation status |
| PATCH | `/api/agent/assign` | Assign agent to conversation |

## Socket.io Events

### Client → Server
- `join_session` - Join a chat room
- `join_dashboard` - Join admin dashboard feed
- `agent_join` - Agent joins specific conversation
- `typing` / `stop_typing` - Typing indicators

### Server → Client
- `conversation_history` - Existing messages on join
- `receive_message` - New message in conversation
- `escalation_event` - Conversation escalated
- `new_message` - Dashboard: new message in any conversation
- `status_change` - Dashboard: conversation status changed
- `agent_takeover` - Dashboard: agent took over
- `agent_assigned` - Dashboard: agent assigned

## Deployment (DigitalOcean)

### 1. Provision Droplet
- Ubuntu 24.04, 2GB+ RAM
- Enable monitoring

### 2. Install Dependencies
```bash
sudo apt update && sudo apt upgrade -y
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs nginx certbot python3-certbot-nginx
```

### 3. Install MongoDB
```bash
curl -fsSL https://www.mongodb.org/static/pgp/server-7.0.asc | sudo gpg -o /usr/share/keyrings/mongodb-server-7.0.gpg --dearmor
echo "deb [ signed-by=/usr/share/keyrings/mongodb-server-7.0.gpg ] https://repo.mongodb.org/apt/ubuntu jammy/mongodb-org/7.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-7.0.list
sudo apt update && sudo apt install -y mongodb-org
sudo systemctl start mongod && sudo systemctl enable mongod
```

### 4. Deploy Application
```bash
cd /var/www
git clone your-repo hotbotstudios
cd hotbotstudios/backend && npm install
cd ../frontend && npm install && npm run build
```

### 5. Process Manager (PM2)
```bash
sudo npm install -g pm2
cd /var/www/hotbotstudios/backend
pm2 start server.js --name hotbot-api
cd ../frontend
pm2 start npm --name hotbot-frontend -- start
pm2 save && pm2 startup
```

### 6. Nginx & SSL
```bash
sudo cp nginx.conf /etc/nginx/sites-available/hotbotstudios.com
sudo ln -s /etc/nginx/sites-available/hotbotstudios.com /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d hotbotstudios.com -d www.hotbotstudios.com
```

## Security Checklist
- [x] No API keys exposed to frontend
- [x] WhatsApp webhook URL server-side only
- [x] CORS restricted to frontend origin
- [x] HTTPS enforced via Nginx
- [x] WebSocket connections secured (WSS)
- [x] Rate limiting on chat endpoint
- [x] Input validation on all routes
- [x] Error messages don't leak internals in production
- [x] MongoDB connection string in env vars only
- [x] Security headers via Nginx

## File Structure

```
hotbot-studios/
├── frontend/                 # Next.js application
│   ├── pages/
│   │   ├── index.js
│   │   ├── automation.js
│   │   ├── ai-agents.js
│   │   ├── growth-systems.js
│   │   ├── case-studies.js
│   │   ├── about.js
│   │   ├── contact.js
│   │   ├── privacy.js
│   │   └── dashboard/
│   │       └── index.js
│   ├── components/
│   │   ├── Navbar.js
│   │   ├── Footer.js
│   │   ├── HeroSection.js
│   │   ├── FeatureGrid.js
│   │   ├── ChatWidget.js
│   │   └── ...
│   └── package.json
│
├── backend/
│   ├── server.js
│   ├── socket.js
│   ├── routes/
│   │   ├── chat.js
│   │   ├── escalate.js
│   │   └── agent.js
│   ├── models/
│   │   └── Conversation.js
│   ├── services/
│   │   ├── ai.js
│   │   └── whatsapp.js
│   ├── .env.example
│   └── package.json
│
├── nginx.conf
└── README.md
```
