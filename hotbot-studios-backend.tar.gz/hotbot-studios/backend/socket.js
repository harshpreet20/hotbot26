const { Server } = require("socket.io");
const Conversation = require("./models/Conversation");

let io;

function initSocket(server) {
  io = new Server(server, {
    cors: {
      origin: process.env.FRONTEND_URL || "http://localhost:3000",
      methods: ["GET", "POST"],
      credentials: true,
    },
    pingTimeout: 60000,
    pingInterval: 25000,
  });

  io.on("connection", (socket) => {
    console.log(`🔌 Socket connected: ${socket.id}`);

    // ─── Join Session Room ─────────────────
    socket.on("join_session", async ({ session_id }) => {
      if (!session_id) return;
      socket.join(session_id);
      console.log(`📌 Socket ${socket.id} joined room ${session_id}`);

      // Send existing messages if conversation exists
      try {
        const conversation = await Conversation.findOne({ session_id });
        if (conversation) {
          socket.emit("conversation_history", {
            messages: conversation.messages,
            mode: conversation.mode,
            status: conversation.status,
          });
        }
      } catch (err) {
        console.error("[Socket] Error fetching history:", err.message);
      }
    });

    // ─── Join Dashboard (Admin) ────────────
    socket.on("join_dashboard", () => {
      socket.join("dashboard");
      console.log(`📊 Dashboard connected: ${socket.id}`);
    });

    // ─── Agent Joins Specific Conversation ─
    socket.on("agent_join", ({ session_id }) => {
      socket.join(session_id);
      console.log(`👤 Agent joined conversation: ${session_id}`);
    });

    // ─── Typing Indicator ──────────────────
    socket.on("typing", ({ session_id, sender }) => {
      socket.to(session_id).emit("typing", { sender });
    });

    socket.on("stop_typing", ({ session_id, sender }) => {
      socket.to(session_id).emit("stop_typing", { sender });
    });

    // ─── Disconnect ────────────────────────
    socket.on("disconnect", (reason) => {
      console.log(`🔌 Socket disconnected: ${socket.id} (${reason})`);
    });
  });

  return io;
}

function getIO() {
  if (!io) throw new Error("Socket.io not initialized. Call initSocket first.");
  return io;
}

module.exports = { initSocket, getIO };
