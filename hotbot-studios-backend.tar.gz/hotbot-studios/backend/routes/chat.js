const express = require("express");
const router = express.Router();
const Conversation = require("../models/Conversation");
const { generateResponse, calculatePriority } = require("../services/ai");
const { getIO } = require("../socket");

/**
 * POST /api/chat
 * Send a message and get AI response
 * Body: { session_id, message, metadata? }
 */
router.post("/", async (req, res) => {
  try {
    const { session_id, message, metadata } = req.body;

    if (!session_id || !message) {
      return res.status(400).json({ error: "session_id and message are required" });
    }

    // Find or create conversation
    let conversation = await Conversation.findOne({ session_id });

    if (!conversation) {
      conversation = new Conversation({
        session_id,
        mode: "ai",
        status: "active",
        messages: [],
        metadata: metadata || {},
      });
    }

    // Add user message
    const userMessage = {
      sender: "user",
      content: message.trim(),
      timestamp: new Date(),
    };
    conversation.messages.push(userMessage);

    // Update priority based on conversation content
    conversation.priority_score = calculatePriority(conversation.messages);

    // Emit user message via socket
    const io = getIO();
    io.to(session_id).emit("receive_message", userMessage);
    io.to("dashboard").emit("new_message", {
      session_id,
      message: userMessage,
      priority: conversation.priority_score,
    });

    // Generate AI response only if in AI mode
    let aiResponse = null;
    if (conversation.mode === "ai") {
      // Emit typing indicator
      io.to(session_id).emit("typing", { sender: "ai" });

      const responseText = await generateResponse(conversation.messages, session_id);

      aiResponse = {
        sender: "ai",
        content: responseText,
        timestamp: new Date(),
      };
      conversation.messages.push(aiResponse);

      // Stop typing and send response
      io.to(session_id).emit("stop_typing", { sender: "ai" });
      io.to(session_id).emit("receive_message", aiResponse);
      io.to("dashboard").emit("new_message", {
        session_id,
        message: aiResponse,
        priority: conversation.priority_score,
      });
    }

    await conversation.save();

    res.json({
      success: true,
      session_id,
      mode: conversation.mode,
      ai_response: aiResponse,
      priority: conversation.priority_score,
    });
  } catch (error) {
    console.error("[Chat Route] Error:", error.message);
    res.status(500).json({ error: "Failed to process message" });
  }
});

/**
 * GET /api/chat/:session_id
 * Retrieve conversation history
 */
router.get("/:session_id", async (req, res) => {
  try {
    const conversation = await Conversation.findOne({
      session_id: req.params.session_id,
    });

    if (!conversation) {
      return res.status(404).json({ error: "Conversation not found" });
    }

    res.json({
      session_id: conversation.session_id,
      mode: conversation.mode,
      status: conversation.status,
      priority: conversation.priority_score,
      assigned_agent: conversation.assigned_agent,
      messages: conversation.messages,
      createdAt: conversation.createdAt,
      updatedAt: conversation.updatedAt,
    });
  } catch (error) {
    console.error("[Chat Route] Error:", error.message);
    res.status(500).json({ error: "Failed to retrieve conversation" });
  }
});

/**
 * GET /api/chat
 * List all conversations (for dashboard)
 * Query: ?status=active&sort=priority
 */
router.get("/", async (req, res) => {
  try {
    const { status, sort = "-updatedAt" } = req.query;
    const filter = {};
    if (status) filter.status = status;

    const conversations = await Conversation.find(filter)
      .sort(sort)
      .select("session_id mode status priority_score assigned_agent messages updatedAt createdAt")
      .lean();

    // Add preview from last message
    const enriched = conversations.map((c) => ({
      ...c,
      preview: c.messages.length > 0
        ? c.messages[c.messages.length - 1].content.substring(0, 100)
        : "No messages",
      message_count: c.messages.length,
    }));

    res.json({ conversations: enriched, total: enriched.length });
  } catch (error) {
    console.error("[Chat Route] Error:", error.message);
    res.status(500).json({ error: "Failed to list conversations" });
  }
});

module.exports = router;
