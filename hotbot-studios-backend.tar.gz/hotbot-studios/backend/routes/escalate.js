const express = require("express");
const router = express.Router();
const Conversation = require("../models/Conversation");
const { sendToWhatsApp } = require("../services/whatsapp");
const { getIO } = require("../socket");

/**
 * POST /api/escalate
 * Escalate a conversation from AI to human agent
 * Body: { session_id, reason? }
 */
router.post("/", async (req, res) => {
  try {
    const { session_id, reason } = req.body;

    if (!session_id) {
      return res.status(400).json({ error: "session_id is required" });
    }

    const conversation = await Conversation.findOne({ session_id });

    if (!conversation) {
      return res.status(404).json({ error: "Conversation not found" });
    }

    if (conversation.status === "escalated") {
      return res.json({
        success: true,
        message: "Conversation already escalated",
        session_id,
      });
    }

    // Update conversation state
    conversation.mode = "human";
    conversation.status = "escalated";
    conversation.priority_score = Math.min(10, conversation.priority_score + 2);

    // Add system message
    const systemMessage = {
      sender: "system",
      content: reason
        ? `Escalated to human agent. Reason: ${reason}`
        : "Conversation escalated to human agent.",
      timestamp: new Date(),
    };
    conversation.messages.push(systemMessage);

    await conversation.save();

    // Send WhatsApp notification via AISensy (non-blocking)
    sendToWhatsApp(conversation).catch((err) => {
      console.error("[Escalate] AISensy WhatsApp failed:", err.message);
    });

    // Also hit n8n escalation webhook if configured (for workflow triggers)
    if (process.env.N8N_ESCALATION_WEBHOOK) {
      const axios = require("axios");
      axios.post(process.env.N8N_ESCALATION_WEBHOOK, {
        session_id: conversation.session_id,
        messages: conversation.messages,
        priority: conversation.priority_score,
        status: "escalated",
        escalated_at: new Date().toISOString(),
      }).catch((err) => {
        console.error("[Escalate] n8n webhook failed:", err.message);
      });
    }

    // Emit escalation event via socket
    const io = getIO();
    io.to(session_id).emit("escalation_event", {
      session_id,
      mode: "human",
      status: "escalated",
      message: systemMessage,
    });

    // Notify dashboard
    io.to("dashboard").emit("escalation_event", {
      session_id,
      priority: conversation.priority_score,
      mode: "human",
      status: "escalated",
    });

    res.json({
      success: true,
      session_id,
      mode: "human",
      status: "escalated",
      priority: conversation.priority_score,
    });
  } catch (error) {
    console.error("[Escalate Route] Error:", error.message);
    res.status(500).json({ error: "Failed to escalate conversation" });
  }
});

module.exports = router;
