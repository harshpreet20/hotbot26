const express = require("express");
const router = express.Router();
const Conversation = require("../models/Conversation");
const { getIO } = require("../socket");

/**
 * POST /api/agent/message
 * Send a message as a human agent
 * Body: { session_id, message, agent_name? }
 */
router.post("/message", async (req, res) => {
  try {
    const { session_id, message, agent_name } = req.body;

    if (!session_id || !message) {
      return res.status(400).json({ error: "session_id and message are required" });
    }

    const conversation = await Conversation.findOne({ session_id });
    if (!conversation) {
      return res.status(404).json({ error: "Conversation not found" });
    }

    const agentMessage = {
      sender: "agent",
      content: message.trim(),
      timestamp: new Date(),
    };
    conversation.messages.push(agentMessage);

    // Ensure mode is human when agent sends
    if (conversation.mode !== "human") {
      conversation.mode = "human";
    }

    if (agent_name && !conversation.assigned_agent) {
      conversation.assigned_agent = agent_name;
    }

    await conversation.save();

    // Emit to user's session and dashboard
    const io = getIO();
    io.to(session_id).emit("receive_message", agentMessage);
    io.to("dashboard").emit("new_message", {
      session_id,
      message: agentMessage,
    });

    res.json({ success: true, message: agentMessage });
  } catch (error) {
    console.error("[Agent Route] Error:", error.message);
    res.status(500).json({ error: "Failed to send agent message" });
  }
});

/**
 * POST /api/agent/takeover
 * Agent takes over a conversation from AI
 * Body: { session_id, agent_name }
 */
router.post("/takeover", async (req, res) => {
  try {
    const { session_id, agent_name } = req.body;

    if (!session_id) {
      return res.status(400).json({ error: "session_id is required" });
    }

    const conversation = await Conversation.findOne({ session_id });
    if (!conversation) {
      return res.status(404).json({ error: "Conversation not found" });
    }

    conversation.mode = "human";
    conversation.assigned_agent = agent_name || "Agent";

    const systemMessage = {
      sender: "system",
      content: `${agent_name || "An agent"} has taken over this conversation.`,
      timestamp: new Date(),
    };
    conversation.messages.push(systemMessage);

    await conversation.save();

    const io = getIO();
    io.to(session_id).emit("receive_message", systemMessage);
    io.to(session_id).emit("escalation_event", {
      session_id,
      mode: "human",
      agent: agent_name,
    });
    io.to("dashboard").emit("agent_takeover", {
      session_id,
      agent: agent_name,
    });

    res.json({ success: true, session_id, mode: "human", agent: agent_name });
  } catch (error) {
    console.error("[Agent Route] Error:", error.message);
    res.status(500).json({ error: "Failed to take over conversation" });
  }
});

/**
 * PATCH /api/agent/status
 * Update conversation status
 * Body: { session_id, status }
 */
router.patch("/status", async (req, res) => {
  try {
    const { session_id, status } = req.body;

    if (!session_id || !status) {
      return res.status(400).json({ error: "session_id and status are required" });
    }

    if (!["active", "escalated", "closed"].includes(status)) {
      return res.status(400).json({ error: "Invalid status" });
    }

    const conversation = await Conversation.findOneAndUpdate(
      { session_id },
      { status },
      { new: true }
    );

    if (!conversation) {
      return res.status(404).json({ error: "Conversation not found" });
    }

    const io = getIO();
    io.to("dashboard").emit("status_change", { session_id, status });

    if (status === "closed") {
      const systemMessage = {
        sender: "system",
        content: "This conversation has been closed.",
        timestamp: new Date(),
      };
      conversation.messages.push(systemMessage);
      await conversation.save();
      io.to(session_id).emit("receive_message", systemMessage);
    }

    res.json({ success: true, session_id, status });
  } catch (error) {
    console.error("[Agent Route] Error:", error.message);
    res.status(500).json({ error: "Failed to update status" });
  }
});

/**
 * PATCH /api/agent/assign
 * Assign an agent to a conversation
 * Body: { session_id, agent_name }
 */
router.patch("/assign", async (req, res) => {
  try {
    const { session_id, agent_name } = req.body;

    if (!session_id || !agent_name) {
      return res.status(400).json({ error: "session_id and agent_name are required" });
    }

    const conversation = await Conversation.findOneAndUpdate(
      { session_id },
      { assigned_agent: agent_name },
      { new: true }
    );

    if (!conversation) {
      return res.status(404).json({ error: "Conversation not found" });
    }

    const io = getIO();
    io.to("dashboard").emit("agent_assigned", { session_id, agent: agent_name });

    res.json({ success: true, session_id, agent: agent_name });
  } catch (error) {
    console.error("[Agent Route] Error:", error.message);
    res.status(500).json({ error: "Failed to assign agent" });
  }
});

module.exports = router;
