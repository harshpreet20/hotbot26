require("dotenv").config();
const express = require("express");
const http = require("http");
const cors = require("cors");
const mongoose = require("mongoose");
const { initSocket } = require("./socket");

const chatRoutes = require("./routes/chat");
const escalateRoutes = require("./routes/escalate");
const agentRoutes = require("./routes/agent");

const app = express();
const server = http.createServer(app);

// ─── Middleware ───────────────────────────────
app.use(cors({
  origin: process.env.FRONTEND_URL || "http://localhost:3000",
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE"],
  credentials: true,
}));
app.use(express.json({ limit: "10mb" }));

// ─── Health Check ────────────────────────────
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// ─── Routes ──────────────────────────────────
app.use("/api/chat", chatRoutes);
app.use("/api/escalate", escalateRoutes);
app.use("/api/agent", agentRoutes);

// ─── Error Handler ───────────────────────────
app.use((err, req, res, next) => {
  console.error("[Server Error]", err.message);
  res.status(err.status || 500).json({
    error: process.env.NODE_ENV === "production" ? "Internal server error" : err.message,
  });
});

// ─── MongoDB + Start ─────────────────────────
const PORT = process.env.PORT || 4000;
const MONGO_URI = process.env.MONGO_URI || "mongodb://localhost:27017/hotbot";

mongoose
  .connect(MONGO_URI)
  .then(() => {
    console.log("✅ MongoDB connected");

    // Initialize Socket.io
    initSocket(server);

    server.listen(PORT, () => {
      console.log(`🚀 HotBot API running on port ${PORT}`);
    });
  })
  .catch((err) => {
    console.error("❌ MongoDB connection failed:", err.message);
    process.exit(1);
  });

module.exports = { app, server };
