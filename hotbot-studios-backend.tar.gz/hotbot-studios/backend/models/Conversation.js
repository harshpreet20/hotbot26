const mongoose = require("mongoose");

const MessageSchema = new mongoose.Schema(
  {
    sender: {
      type: String,
      enum: ["user", "ai", "agent", "system"],
      required: true,
    },
    content: {
      type: String,
      required: true,
    },
    timestamp: {
      type: Date,
      default: Date.now,
    },
  },
  { _id: false }
);

const ConversationSchema = new mongoose.Schema(
  {
    session_id: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },
    mode: {
      type: String,
      enum: ["ai", "human"],
      default: "ai",
    },
    status: {
      type: String,
      enum: ["active", "escalated", "closed"],
      default: "active",
    },
    assigned_agent: {
      type: String,
      default: null,
    },
    priority_score: {
      type: Number,
      default: 5,
      min: 1,
      max: 10,
    },
    messages: [MessageSchema],
    metadata: {
      user_agent: String,
      ip_address: String,
      referrer: String,
      page_url: String,
    },
  },
  {
    timestamps: true, // createdAt + updatedAt
  }
);

// Index for dashboard queries
ConversationSchema.index({ status: 1, updatedAt: -1 });
ConversationSchema.index({ priority_score: -1 });

module.exports = mongoose.model("Conversation", ConversationSchema);
