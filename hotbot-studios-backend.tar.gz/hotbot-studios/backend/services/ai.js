const OpenAI = require("openai");
const axios = require("axios");

/**
 * Dual-mode AI Service
 *
 * Mode 1 (n8n): When N8N_AI_WEBHOOK is set, routes messages through n8n
 *   → n8n handles OpenAI + Google Drive RAG + vector store retrieval
 *   → Returns enriched response with document context
 *
 * Mode 2 (Direct): When N8N_AI_WEBHOOK is NOT set, calls OpenAI directly
 *   → Standard chat completion without RAG
 *   → Simpler but no document knowledge base
 */

// ─── Direct OpenAI Client ────────────────────
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const SYSTEM_PROMPT = `You are HotBot Studios AI assistant.
You help businesses with automation, AI agents, growth systems.
Be strategic.
Be concise.
Qualify leads.
Push toward booking a call.

Key services:
- AI Automation: End-to-end workflow automation for enterprises
- AI Agents: 24/7 autonomous agents for lead qualification, customer support, sales
- Growth Systems: Data-driven infrastructure for systematic business growth

When qualifying leads, naturally ask about:
- Their current team size and monthly lead volume
- Main operational bottlenecks
- Budget range and timeline
- Decision-making process

Always be helpful, professional, and conversion-focused.
Keep responses concise (2-4 sentences unless detail is needed).
If the user seems highly qualified, push toward scheduling a strategy call.
If the conversation needs human expertise, suggest escalation.`;

/**
 * Generate AI response — automatically picks n8n or direct mode.
 *
 * @param {Array} messages - Array of { sender, content } objects
 * @param {string} session_id - Conversation session ID
 * @returns {string} AI response text
 */
async function generateResponse(messages, session_id) {
  const n8nWebhook = process.env.N8N_AI_WEBHOOK;

  if (n8nWebhook) {
    return generateViaN8N(messages, session_id, n8nWebhook);
  }
  return generateDirect(messages);
}

/**
 * Mode 1: Route through n8n for RAG-powered responses.
 * n8n handles: OpenAI API call + Google Drive doc retrieval + vector search
 */
async function generateViaN8N(messages, session_id, webhookUrl) {
  try {
    const recentMessages = messages.slice(-10).map((m) => ({
      sender: m.sender,
      content: m.content,
      timestamp: m.timestamp,
    }));

    const response = await axios.post(
      webhookUrl,
      {
        session_id,
        messages: recentMessages,
        last_message: recentMessages[recentMessages.length - 1]?.content || "",
        timestamp: new Date().toISOString(),
      },
      {
        headers: { "Content-Type": "application/json" },
        timeout: 30000, // 30s timeout — n8n RAG can take longer
      }
    );

    // n8n should return { reply: "..." } or { output: "..." }
    const data = response.data;
    const reply = data.reply || data.output || data.text || data.message;

    if (reply && typeof reply === "string") {
      return reply.trim();
    }

    // If n8n returns unexpected format, try to extract
    if (typeof data === "string") return data.trim();

    console.warn("[AI/n8n] Unexpected response format:", JSON.stringify(data).substring(0, 200));
    return "I'd love to help you with that. Could you tell me more about what you're looking for? Or click 'Talk to Human' to connect directly with our team.";
  } catch (error) {
    console.error("[AI/n8n] Webhook error:", error.message);

    // Fallback to direct OpenAI if n8n fails
    console.log("[AI] Falling back to direct OpenAI...");
    try {
      return await generateDirect(messages);
    } catch (fallbackError) {
      return "I'm experiencing a brief technical issue. Please click 'Talk to Human' above for immediate assistance from our team.";
    }
  }
}

/**
 * Mode 2: Direct OpenAI call (no RAG, no document context).
 */
async function generateDirect(messages) {
  try {
    const recentMessages = messages.slice(-10);

    const formattedMessages = [
      { role: "system", content: SYSTEM_PROMPT },
      ...recentMessages.map((msg) => ({
        role: msg.sender === "user" ? "user" : "assistant",
        content: msg.content,
      })),
    ];

    const completion = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      messages: formattedMessages,
      max_tokens: 300,
      temperature: 0.7,
      presence_penalty: 0.3,
      frequency_penalty: 0.3,
    });

    return completion.choices[0].message.content.trim();
  } catch (error) {
    console.error("[AI/Direct] OpenAI error:", error.message);

    if (error.code === "insufficient_quota") {
      return "I apologize, but I'm experiencing a temporary issue. Please try again in a moment, or click 'Talk to Human' to connect with our team directly.";
    }
    return "I'm having a brief technical hiccup. Let me connect you with our team — click 'Talk to Human' above for immediate assistance.";
  }
}

/**
 * Calculate priority score based on conversation content.
 */
function calculatePriority(messages) {
  let score = 5;
  const fullText = messages.map((m) => m.content).join(" ").toLowerCase();

  const highValue = [
    "enterprise", "fortune", "million", "budget", "team of",
    "company-wide", "urgent", "asap", "ready to start", "decision maker",
  ];
  const medium = [
    "pricing", "cost", "demo", "interested", "looking for",
    "need help", "automation", "scale",
  ];
  const low = ["just browsing", "curious", "maybe", "not sure"];

  highValue.forEach((kw) => { if (fullText.includes(kw)) score = Math.min(10, score + 1); });
  medium.forEach((kw) => { if (fullText.includes(kw)) score = Math.min(10, score + 0.5); });
  low.forEach((kw) => { if (fullText.includes(kw)) score = Math.max(1, score - 1); });

  return Math.round(Math.min(10, Math.max(1, score)));
}

module.exports = { generateResponse, calculatePriority };
