const axios = require("axios");

/**
 * AISensy WhatsApp Business API Service
 *
 * API Endpoint: POST https://backend.aisensy.com/campaign/t1/api/v2
 *
 * Prerequisites:
 *   1. Verified WhatsApp Business API on AISensy
 *   2. Approved template message for escalation notifications
 *   3. Live API Campaign created in AISensy dashboard
 *
 * Environment Variables Required:
 *   AISENSY_API_KEY       - From AISensy Dashboard > Manage > API Key
 *   AISENSY_CAMPAIGN_NAME - Name of your live API campaign for escalation alerts
 *   AGENT_WHATSAPP_NUMBER - Agent's WhatsApp number with country code (+919876543210)
 *   AGENT_NAME            - Display name for the receiving agent
 */

const AISENSY_API_URL = "https://backend.aisensy.com/campaign/t1/api/v2";

/**
 * Send escalation notification to human agent via AISensy WhatsApp API.
 * Triggers an approved template message to the assigned agent's WhatsApp.
 *
 * @param {Object} conversation - Mongoose conversation document
 * @returns {Object} AISensy API response
 */
async function sendToWhatsApp(conversation) {
  const apiKey = process.env.AISENSY_API_KEY;
  const campaignName = process.env.AISENSY_CAMPAIGN_NAME;
  const agentNumber = process.env.AGENT_WHATSAPP_NUMBER;
  const agentName = process.env.AGENT_NAME || "HotBot Agent";

  if (!apiKey || !campaignName || !agentNumber) {
    console.error(
      "[AISensy] Missing required env vars: AISENSY_API_KEY, AISENSY_CAMPAIGN_NAME, or AGENT_WHATSAPP_NUMBER"
    );
    throw new Error("AISensy WhatsApp configuration incomplete");
  }

  try {
    // Build conversation summary for template params
    const userMessages = conversation.messages
      .filter((m) => m.sender === "user")
      .map((m) => m.content);

    const lastUserMessage = userMessages[userMessages.length - 1] || "No message";
    const messageCount = conversation.messages.length.toString();
    const priority = conversation.priority_score.toString();
    const sessionId = conversation.session_id;

    // ─────────────────────────────────────────────────────────────────
    // IMPORTANT: templateParams must match YOUR approved AISensy template
    //
    // Example approved template (create this in AISensy dashboard):
    //   "🔥 New Chat Escalation
    //    Session: {{1}}
    //    Priority: {{2}}/10
    //    Last message: {{3}}
    //    Total messages: {{4}}"
    //
    // Adjust the array below to match your template's variable count
    // ─────────────────────────────────────────────────────────────────
    const payload = {
      apiKey: apiKey,
      campaignName: campaignName,
      destination: agentNumber,
      userName: agentName,
      source: "HotBot Website Chat",
      templateParams: [
        sessionId.substring(0, 30),           // {{1}} Session ID
        priority,                              // {{2}} Priority score
        lastUserMessage.substring(0, 200),     // {{3}} Last user message
        messageCount,                          // {{4}} Message count
      ],
      tags: ["escalation", `priority-${priority}`],
      attributes: {
        session_id: sessionId,
        escalation_source: "website_chat",
        priority_score: priority,
      },
    };

    const response = await axios.post(AISENSY_API_URL, payload, {
      headers: { "Content-Type": "application/json" },
      timeout: 15000,
    });

    console.log(`[AISensy] ✅ Escalation sent for session ${sessionId} → ${agentNumber}`);
    return { success: true, status: response.status, data: response.data };
  } catch (error) {
    const errMsg = error.response?.data || error.message;
    console.error("[AISensy] ❌ WhatsApp API error:", errMsg);
    return {
      success: false,
      error: typeof errMsg === "object" ? JSON.stringify(errMsg) : errMsg,
    };
  }
}

/**
 * Send a direct template message to any WhatsApp number via AISensy.
 * Useful for follow-ups, confirmations, or agent-initiated messages.
 *
 * @param {string} phoneNumber - Recipient phone with country code (+91...)
 * @param {string} userName - Recipient display name
 * @param {string} campaignName - Name of the approved API campaign in AISensy
 * @param {Array<string>} templateParams - Array of template variable values
 * @param {Object} [media] - Optional media { url: string, filename: string }
 * @returns {Object} API response
 */
async function sendDirectMessage(phoneNumber, userName, campaignName, templateParams = [], media = null) {
  const apiKey = process.env.AISENSY_API_KEY;
  if (!apiKey) throw new Error("AISENSY_API_KEY not configured");

  try {
    const payload = {
      apiKey,
      campaignName,
      destination: phoneNumber,
      userName,
      source: "HotBot Direct",
      templateParams,
    };

    // Attach media if provided (URL must be publicly accessible)
    if (media && media.url) {
      payload.media = {
        url: media.url,
        filename: media.filename || "document",
      };
    }

    const response = await axios.post(AISENSY_API_URL, payload, {
      headers: { "Content-Type": "application/json" },
      timeout: 15000,
    });

    console.log(`[AISensy] Direct message sent to ${phoneNumber}`);
    return { success: true, data: response.data };
  } catch (error) {
    console.error("[AISensy] Direct message error:", error.response?.data || error.message);
    return { success: false, error: error.message };
  }
}

module.exports = { sendToWhatsApp, sendDirectMessage };
